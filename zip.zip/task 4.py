def print_chars_with_index(s):
    # Iterate over the string with index using enumerate
    for index, char in enumerate(s):
        # Print each character with its index
        print(f"Index {index}: {char}")

# Example usage
print_chars_with_index("hello")
