def count_char_occurrences(s, char):
    # Initialize a counter
    count = 0
    
    # Iterate over the string
    for c in s:
        # If the current character matches the specified character, increment the counter
        if c == char:
            count += 1
            
    # Return the final count
    return count

# Example usage
print(count_char_occurrences("hello world", 'l'))  # Output: 3
print(count_char_occurrences("hello world", 'o'))  # Output: 2
print(count_char_occurrences("hello world", 'x'))  # Output: 0
