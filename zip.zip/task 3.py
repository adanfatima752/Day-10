def lengths_of_strings(strings):
    # Use a list comprehension to create a new list containing the lengths of the strings
    return [len(s) for s in strings]
print(lengths_of_strings(["hello", "world", "Python", "is", "awesome"]))  
# Output: [5, 5, 6, 2, 7]
