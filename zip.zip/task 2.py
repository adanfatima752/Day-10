def char_at_index(s, index):
    # Check if the index is within the bounds of the string
    if index < 0 or index >= len(s):
        return "Index out of bounds"
    else:
        # Return the character at the given index
        return s[index]
print(char_at_index("hello", 1))  # Output: "e"
print(char_at_index("hello", 5))  # Output: "Index out of bounds"
print(char_at_index("hello", -1))  # Output: "Index out of bounds"
